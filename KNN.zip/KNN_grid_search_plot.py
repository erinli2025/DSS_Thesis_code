#!/usr/bin/env python
# coding: utf-8

# In[1]:




import pandas as pd
from sklearn.neighbors import KNeighborsRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.metrics.pairwise import cosine_similarity
import os
import matplotlib.pyplot as plt
import numpy as np
from itertools import product


LABEL_DIR = r"D:\\谷歌下载\\thesis_doc"
BOW_DIR = r"D:\\谷歌下载\\thesis_doc\\bow_features"


train_bow = pd.read_csv(os.path.join(BOW_DIR, "train_bow.csv"))
val_bow = pd.read_csv(os.path.join(BOW_DIR, "val_bow.csv"))
test_bow = pd.read_csv(os.path.join(BOW_DIR, "test_bow.csv"))

train_labels = pd.read_csv(os.path.join(LABEL_DIR, "train_labels.csv"))
val_labels = pd.read_csv(os.path.join(LABEL_DIR, "val_labels.csv"))
test_labels = pd.read_csv(os.path.join(LABEL_DIR, "test_labels.csv"))


train = pd.merge(train_bow, train_labels, left_on='image_id', right_on='image_name')
val = pd.merge(val_bow, val_labels, left_on='image_id', right_on='image_name')
test = pd.merge(test_bow, test_labels, left_on='image_id', right_on='image_name')


X_train = train.drop(columns=['image_id', 'image_name', 'owner', 'split'])
X_val = val.drop(columns=['image_id', 'image_name', 'owner', 'split'])
X_test = test.drop(columns=['image_id', 'image_name', 'owner', 'split'])


soft_label_cols = ['Auto Dealers', 'Business & Utility Services', 'Content & Apps', 'Creators & Celebrities',
                   'Entities', 'Food & Personal Goods', 'General Interest', 'Geography', 'Government Agencies',
                   'Grocery & Convenience Stores', 'Home & Auto', 'Home Goods Stores', 'Home Services',
                   'Lifestyle Services', 'Local Events', 'Non-Profits & Religious Organizations',
                   'Personal Goods & General Merchandise Stores', 'Professional Services', 'Publishers',
                   'Restaurants', 'Transportation & Accomodation Services']

y_train = train[soft_label_cols]
y_val = val[soft_label_cols]
y_test = test[soft_label_cols]

#  Grid Search
k_list = [3, 5, 7, 10, 15]
metric_list = ["euclidean", "manhattan", "cosine"]
weights_list = ["uniform", "distance"]

param_grid = list(product(k_list, metric_list, weights_list))

results = []

print("\nStarting KNN Hyperparameter Tuning...")
for k, metric, weights in param_grid:
    try:
        print(f"Training: k={k}, metric={metric}, weights={weights}")
        knn = KNeighborsRegressor(n_neighbors=k, metric=metric, weights=weights)
        model = MultiOutputRegressor(knn)
        model.fit(X_train, y_train)

        # predict on val
        y_val_pred = model.predict(X_val)

        val_mse = mean_squared_error(y_val, y_val_pred)
        val_mae = mean_absolute_error(y_val, y_val_pred)
        val_cosine_sim = np.mean([cosine_similarity([y_val.iloc[i]], [y_val_pred[i]])[0][0] for i in range(len(y_val))])

        results.append({"k": k, "metric": metric, "weights": weights,
                        "val_mse": val_mse, "val_mae": val_mae, "val_cosine": val_cosine_sim})
    except Exception as e:
        print(f"Error with k={k}, metric={metric}, weights={weights}: {e}")


results_df = pd.DataFrame(results)
print("\nTuning Results:")
print(results_df.sort_values(by="val_mse"))

#plot
plt.figure(figsize=(14, 7))
for metric in metric_list:
    subset = results_df[results_df['metric'] == metric]
    plt.plot(subset['k'], subset['val_mse'], label=f"{metric} - uniform", marker='o')

plt.xlabel("k")
plt.ylabel("Validation MSE")
plt.title("KNN Hyperparameter Tuning - Validation MSE by Metric")
plt.legend()
plt.grid(True)
plt.show()

print("\nAll done tuning! 🎯")


# In[2]:


plt.figure(figsize=(14, 7))
for metric in metric_list:
    for weights in weights_list:
        subset = results_df[(results_df['metric'] == metric) & (results_df['weights'] == weights)]
        if not subset.empty:
            plt.plot(subset['k'], subset['val_mse'], label=f"{metric} - {weights}", marker='o')

plt.xlabel("k")
plt.ylabel("Validation MSE")
plt.title("KNN Hyperparameter Tuning - Validation MSE by Metric & Weights")
plt.legend()
plt.grid(True)
plt.show()


# In[1]:


# =train final model
print("\nTraining final KNN model with best hyperparameters...")
knn_final = KNeighborsRegressor(n_neighbors=15, metric='manhattan', weights='distance')
final_model = MultiOutputRegressor(knn_final, n_jobs=1)
final_model.fit(X_train, y_train)

# model save
model_path = os.path.join(SAVE_DIR, "final_knn_model.pkl")
joblib.dump(final_model, model_path)
print(f"Model saved to {model_path}")

#predict on test
print("\nPredicting on test set...")
y_test_pred = final_model.predict(X_test)

test_mse = mean_squared_error(y_test, y_test_pred)
test_mae = mean_absolute_error(y_test, y_test_pred)
test_cosine_sim = np.mean([cosine_similarity([y_test.iloc[i]], [y_test_pred[i]])[0][0] for i in range(len(y_test))])

print("\nFinal Test Results:")
print(f"Test MSE: {test_mse:.6f}")
print(f"Test MAE: {test_mae:.6f}")
print(f"Test Cosine Similarity: {test_cosine_sim:.6f}")

print("\nAll done! 🎯")


# In[2]:


# save result
y_test_pred_df = pd.DataFrame(y_test_pred, columns=soft_label_cols)
y_test_pred_df.to_csv(os.path.join(SAVE_DIR, "test_knn_predictions.csv"), index=False)
print("Test predictions saved!")

print("\nAll done! 🎯")


# In[6]:


# plot
print("\nPlotting per-category MSE...")
category_mse = ((y_test.values - y_test_pred) ** 2).mean(axis=0)


mse_df = pd.DataFrame({
    'Category': soft_label_cols,
    'MSE': category_mse
})


mse_df = mse_df.sort_values(by="MSE", ascending=False)


plt.figure(figsize=(14, 6))
plt.barh(mse_df['Category'], mse_df['MSE'])
plt.xlabel("MSE")
plt.title("Per-category MSE on Test Set (Descending)")
plt.gca().invert_yaxis()  # 横向柱状图默认y是从下到上，需要翻过来
plt.grid(True)
plt.tight_layout()
plt.show()


# In[1]:


mse_df


# In[7]:


#  per-category MSE、MAE、Cosine
category_mse = ((y_test.values - y_test_pred) ** 2).mean(axis=0)
category_mae = np.abs(y_test.values - y_test_pred).mean(axis=0)


category_cosine = []
for i in range(y_test.shape[1]):
    cos_sim = cosine_similarity(y_test.iloc[:, i].values.reshape(-1, 1),
                                 y_test_pred[:, i].reshape(-1, 1)).mean()
    category_cosine.append(1 - cos_sim) 

category_cosine = np.array(category_cosine)



mse_df = pd.DataFrame({'Category': soft_label_cols, 'MSE': category_mse})
mse_df = mse_df.sort_values(by="MSE", ascending=False)

plt.figure(figsize=(14, 6))
plt.barh(mse_df['Category'], mse_df['MSE'])
plt.xlabel("MSE")
plt.title("Per-category MSE on Test Set (Descending)")
plt.gca().invert_yaxis()
plt.grid(True)
plt.tight_layout()
plt.show()


mae_df = pd.DataFrame({'Category': soft_label_cols, 'MAE': category_mae})
mae_df = mae_df.sort_values(by="MAE", ascending=False)

plt.figure(figsize=(14, 6))
plt.barh(mae_df['Category'], mae_df['MAE'])
plt.xlabel("MAE")
plt.title("Per-category MAE on Test Set (Descending)")
plt.gca().invert_yaxis()
plt.grid(True)
plt.tight_layout()
plt.show()

cosine_df = pd.DataFrame({'Category': soft_label_cols, 'Cosine_Error': category_cosine})
cosine_df = cosine_df.sort_values(by="Cosine_Error", ascending=False)

plt.figure(figsize=(14, 6))
plt.barh(cosine_df['Category'], cosine_df['Cosine_Error'])
plt.xlabel("1 - Cosine Similarity")
plt.title("Per-category 1-Cosine Error on Test Set (Descending)")
plt.gca().invert_yaxis()
plt.grid(True)
plt.tight_layout()
plt.show()


# In[4]:


# MSE per catagory 
print("\nPlotting per-category MSE...")
category_mse = ((y_test.values - y_test_pred) ** 2).mean(axis=0)

plt.figure(figsize=(14, 6))
plt.barh(soft_label_cols, category_mse)
plt.xlabel("MSE")
plt.title("Per-category MSE on Test Set")
plt.grid(True)
plt.tight_layout()
plt.show()

# Save MAE &MSE
category_mae = np.abs(y_test.values - y_test_pred).mean(axis=0)
metrics_df = pd.DataFrame({
    'Category': soft_label_cols,
    'MSE': category_mse,
    'MAE': category_mae
})
metrics_df_sorted = metrics_df.sort_values(by="MSE")
metrics_df_sorted.to_csv(os.path.join(SAVE_DIR, "per_category_mse_mae.csv"), index=False)

print("Per-category MSE and MAE saved! 🎯")

print("\nAll done! 🎯")


# In[9]:

#check the data leakage 

val_bow_features = val_bow.drop(columns=['image_id'])
test_bow_features = test_bow.drop(columns=['image_id'])
import numpy as np
import matplotlib.pyplot as plt


val_mean = np.mean(val_bow_features.values, axis=0)
test_mean = np.mean(test_bow_features.values, axis=0)


feature_indices = np.arange(50)

plt.figure(figsize=(12,6))
plt.plot(feature_indices, val_mean[:50], label='Validation Mean')
plt.plot(feature_indices, test_mean[:50], label='Test Mean', linestyle='dashed')
plt.xlabel('Feature Index')
plt.ylabel('Mean Value')
plt.title('BoW Feature Mean Comparison (First 50 Features)')
plt.legend()
plt.grid(True)
plt.show()


# In[10]:


from sklearn.decomposition import PCA

# Step 1 combine val and test
bow_combined = np.vstack((val_bow_features.values, test_bow_features.values))
labels = np.array([0] * val_bow_features.shape[0] + [1] * test_bow_features.shape[0])  # 0 for val, 1 for test

# Step 2: PCA
pca = PCA(n_components=2)
bow_pca = pca.fit_transform(bow_combined)

# Step 3: plot
plt.figure(figsize=(8,6))
plt.scatter(bow_pca[labels==0, 0], bow_pca[labels==0, 1], alpha=0.5, label='Validation')
plt.scatter(bow_pca[labels==1, 0], bow_pca[labels==1, 1], alpha=0.5, label='Test', marker='x')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.title('PCA of Validation vs Test BoW Features')
plt.legend()
plt.grid(True)
plt.show()


# In[11]:


from scipy.stats import ks_2samp

ks_pvalues = []
for i in range(val_bow_features.shape[1]):
    ks_stat, p_value = ks_2samp(val_bow_features.values[:, i], test_bow_features.values[:, i])
    ks_pvalues.append(p_value)

ks_pvalues = np.array(ks_pvalues)

#overall p-value distribution
print(f'中位数p值: {np.median(ks_pvalues):.4f}')
print(f'p>0.05比例: {(ks_pvalues > 0.05).mean()*100:.2f}%')

# plot p
plt.figure(figsize=(8,6))
plt.hist(ks_pvalues, bins=30)
plt.xlabel('P-value')
plt.ylabel('Feature Count')
plt.title('Distribution of KS-test P-values Across Features')
plt.grid(True)
plt.show()







