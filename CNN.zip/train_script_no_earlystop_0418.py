
#!/usr/bin/env python
# coding: utf-8

import os
import zipfile
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
from tqdm import tqdm
import numpy as np

# ------------------- Config -------------------
DATA_DIR = os.path.expanduser("~/thesis_data")
TRAIN_ZIP = os.path.join(DATA_DIR, "train.zip")
VAL_ZIP = os.path.join(DATA_DIR, "val.zip")
TRAIN_LABELS = os.path.join(DATA_DIR, "train_labels.csv")
VAL_LABELS = os.path.join(DATA_DIR, "val_labels.csv")
CHECKPOINT_PATH = "checkpoint.pth"
BEST_MODEL_PATH = "model_best.pth"
LOG_PATH = "log.csv"

NUM_EPOCHS = 20  # 设置为固定轮数
BATCH_SIZE = 32
IMG_SIZE = 224
LR = 1e-4

# ------------------- Dataset -------------------
class ZipDataset(Dataset):
    def __init__(self, zip_path, labels_csv, transform=None):
        self.zip_path = zip_path
        self.zip_file = zipfile.ZipFile(zip_path, 'r')
        self.data = pd.read_csv(labels_csv)
        self.transform = transform

        self.image_names = self.data['image_name'].tolist()
        self.label_cols = [col for col in self.data.columns if col not in ['image_name', 'owner', 'split']]
        self.labels = self.data[self.label_cols].values.astype('float32')

    def __len__(self):
        return len(self.image_names)

    def __getitem__(self, idx):
        img_name = self.image_names[idx]
        label = self.labels[idx]

        with self.zip_file.open(img_name) as file:
            img = Image.open(file).convert('RGB')
            if self.transform:
                img = self.transform(img)

        return img, torch.tensor(label)

# ------------------- Transforms -------------------
transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# ------------------- Loaders -------------------
train_set = ZipDataset(TRAIN_ZIP, TRAIN_LABELS, transform)
val_set = ZipDataset(VAL_ZIP, VAL_LABELS, transform)

train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_set, batch_size=BATCH_SIZE, shuffle=False)

# ------------------- Model -------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
model.fc = nn.Sequential(
    nn.Linear(model.fc.in_features, len(train_set.label_cols)),
    nn.Sigmoid()
)
model = model.to(device)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

# ------------------- Resume if exists -------------------
best_val_loss = float('inf')
start_epoch = 0

if os.path.exists(CHECKPOINT_PATH):
    checkpoint = torch.load(CHECKPOINT_PATH)
    model.load_state_dict(checkpoint['model'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    start_epoch = checkpoint['epoch'] + 1
    best_val_loss = checkpoint['best_val_loss']
    print(f"\n✅ 恢复训练：从 epoch {start_epoch} 继续...\n")

# ------------------- Training -------------------
log = []

for epoch in range(start_epoch, NUM_EPOCHS):
    model.train()
    total_loss = 0.0
    for imgs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{NUM_EPOCHS} [Train]"):
        imgs, labels = imgs.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(imgs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * imgs.size(0)

    avg_train_loss = total_loss / len(train_loader.dataset)

    # ----- 验证 -----
    model.eval()
    total_val_loss = 0.0
    with torch.no_grad():
        for imgs, labels in tqdm(val_loader, desc=f"Epoch {epoch+1}/{NUM_EPOCHS} [Val]"):
            imgs, labels = imgs.to(device), labels.to(device)
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            total_val_loss += loss.item() * imgs.size(0)

    avg_val_loss = total_val_loss / len(val_loader.dataset)

    # ----- 日志 -----
    log.append((epoch+1, avg_train_loss, avg_val_loss))
    pd.DataFrame(log, columns=['epoch', 'train_loss', 'val_loss']).to_csv(LOG_PATH, index=False)
    print(f"\n📘 Epoch {epoch+1} | Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}")

    # ----- 保存模型 -----
    torch.save({
        'epoch': epoch,
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'best_val_loss': best_val_loss
    }, CHECKPOINT_PATH)

    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        torch.save(model.state_dict(), BEST_MODEL_PATH)
        print("✨ 保存最佳模型！")
